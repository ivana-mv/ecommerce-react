import React from 'react';
import rsz_rocket from '../../img/rsz_rocket.jpg'
import useAppContext from '../../Context/useAppContext';
import Button from "react-bootstrap/Button";
import { Link } from 'react-router-dom';

export default function Icon() {
/*
    const { arrayLength } = useAppContext()
*/
    return(
        <>  
             <Link to={'/Cart'}>
                  <Button variant="primary">Cart</Button>
                </Link>
        <img src={rsz_rocket} alt="Icon-rocket"></img>
        <h1>{/*arrayLength()*/}</h1>
        </>
    )
} 
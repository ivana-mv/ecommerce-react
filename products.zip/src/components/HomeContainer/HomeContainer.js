import React, { useEffect, useState } from 'react';
import ItemList from '../ItemList/ItemList';
import { getProducts } from '../../firebase/index';

//Llamado a la promise que devuelve un listado de productos para la Home

const HomeContainer = () => {

    const [items, setItems] = useState([]) //El setState recibe un array

    useEffect(() => { //espero que me devuelva la respuesta 
        getProducts()
            .then(response => {
                setItems(response)
                console.table(response)
         }, 
            err => {
             console.error(err)
         })
            .catch(err=> {
             console.log(err)
         })
            .finally(()=> {})
    }, [])


//Le paso por props el items array a ItemList

    return (
        <>
            <p>Home</p>
            <ItemList items={items}></ItemList> 

        </>
    )
    
}


export default HomeContainer;
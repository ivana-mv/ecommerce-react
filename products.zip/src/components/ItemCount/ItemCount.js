import React, { useState } from 'react';
import Button from 'react-bootstrap/Button';


export default function CountItem ({initialValue, maxValue, onAdd}){
    const [contador, setContador] = useState(initialValue);

    const incrementar = () => {
        setContador(Math.min(contador+1,maxValue));
        onAdd(contador+1);
}

    const decrementar = () => {
       setContador(Math.max(contador-1, initialValue));
    }


    return (
        <div className="contador" style={{ 
            marginLeft: 800}}>
            <h1 className="cont-text" style={{
            marginLeft: 90    
            }}>{contador}</h1>
            <Button variant="outline-dark" onClick={() => {decrementar()}}>-</Button>
            <Button variant="outline-dark" onClick={() => {incrementar()}}>+</Button>
       
        </div>
    );
}



import React from 'react';
import { useEffect, useState } from 'react';
import getProductsFromDataBase from '../Item/Item';
import Card from "react-bootstrap/Card";
import Button from "react-bootstrap/Button";
import './ItemList.scss';
import Item from '../Item/Item';

const ItemList = ({ items }) => {

    return(
        <>
        <p>ItemList</p>
        {items.map((item, idx) => {
            return (
                <Item  key={idx} item= {item}></Item>
            )
        })}
        </>
    )
}

export default ItemList
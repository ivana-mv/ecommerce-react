import React from 'react'; //imr 
import { Link } from 'react-router-dom'
import './navBar.scss';
import {Navbar, Nav} from 'react-bootstrap';
import Icon from '../CartIcon/CartIcon.js';

export default function NavBar(){
  return(
    <>
    <Navbar bg="dark" variant="dark" style={{ minWidth: 700 }}>
      <Navbar.Brand href="#home">e-Commerce</Navbar.Brand>
      <Nav className="mr-auto">
        <Nav.Link href="#home">Home</Nav.Link>
        <Nav.Link href="#contacto">Contacto</Nav.Link>
        <Nav.Link href="#checkOut">Mi Carrito</Nav.Link>
      </Nav>
      <Icon></Icon>
    </Navbar>
  </>
  )
}
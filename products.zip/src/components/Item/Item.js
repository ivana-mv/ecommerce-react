import React from 'react';
import { Link } from 'react-router-dom';
import Card from "react-bootstrap/Card";
import Button from "react-bootstrap/Button";
import './Item.scss';
import { useContext } from 'react';
import useAppContext from '../../Context/useAppContext'

//Json de productos en forma de función para llamarlo en mi home
const Item = ({item}) => {
////item para HOME!!!!!!


  return (
    <>


     <div className="cards">
      <Card className="card-each" style={{ width: '18rem' }}>
                            <Card.Img variant="top" src={item.imagen} />
                            <Card.Body>
                            <Card.Title>{item.productName}</Card.Title>
                            <Card.Text>
                                Some quick example text to build on the card title and make up the bulk of
                                the card's content.
                            </Card.Text>
                            <Link to={'/Detalle/'+item.id}>
                               <Button  variant="primary">Go somewhere</Button>
                            </Link>
                            </Card.Body>
                       </Card>
      </div>
    
      
    </>

  )
}

export default Item
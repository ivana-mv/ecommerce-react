import React, { useEffect, useState } from 'react';
import ItemCount from '../ItemCount/ItemCount';
import { useContext } from 'react';
import useAppContext from '../../Context/useAppContext'
import Card from "react-bootstrap/Card";
import Button from "react-bootstrap/Button";
import './ItemDetail.scss';

const ItemDetail = ({product}) => {

      const [quantity, setCounter] = useState(1)
      const {addProduct} = useAppContext();

      const handleCounter = (counter) => {
        setCounter(counter)
      }

      const addProductToCart = () => {
        addProduct(product, quantity);
        console.log({...product, quantity});
      }

      /*
        const [product] = products;

        const mostrarConsola = (contador) => {
            console.log(contador)
        }
        
        const actualizar = (contador) => {
          console.log(contador)
        }

        const { dummyObject, handleDummyObject } = useAppContext()

        const handleProduct = () => {
          handleDummyObject(product);
          }
        */
          

  return (
    <>
            <h1>Producto ID: {product.id}</h1>
            <Card className="text-center card-detail">
              <Card.Header>Detalle producto</Card.Header>
              <Card.Body>
                <Card.Title>{product.productName}</Card.Title>
                <Button onClick={handleCounter} variant="primary">comprar</Button>
                <Button onClick={addProductToCart} variant = "secondary">Agregar al carrito</Button>
              </Card.Body>
              <Card.Footer className="text-muted">2 days ago</Card.Footer>
            </Card>

          <div>
            {/*prodFirebase ?
            prodFirebase.map(element => {
              return <p>{element.name}</p>
            }):'cargando*/}
          </div>

      <ItemCount onAdd={handleCounter} initialValue={0} maxValue={15}></ItemCount>

    </>

  )
}

export default ItemDetail



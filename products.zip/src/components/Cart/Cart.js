import React from 'react';
import { Link } from 'react-router-dom';
import { useContext } from 'react';
import useAppContext from '../../Context/useAppContext';
import Button from "react-bootstrap/Button";

export default function Cart() {

    const { products } = useAppContext()
    console.log(products)

    return(
        <>
            <h1>Cart</h1>
            {products.map(products => <h2>{products.productName}</h2>)}
            <Link to={'/'}>
                <Button variant="primary">Volver al home</Button>
            </Link>
        </>
    )
}
import React from 'react';
import {BrowserRouter, Switch, Route, NavLink} from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import NavBar from './components/NavBar/Navbar';
import './App.css';
import HomeContainer from './components/HomeContainer/HomeContainer';
import ItemDetailContainer from './components/ItemDetailContainer/ItemDetailContainer';
import Home from './Screens/Home/Index';
import Detalle from './Screens/Detalle/Index'
import Ofertas from './Screens/Ofertas';
import { AppProvider } from './Context/useAppContext';
import Cart from './components/Cart/Cart';


function App() {
  return (
    <AppProvider>
      <BrowserRouter>
      <NavBar></NavBar>

        <Switch>
          <>
          <Route exact path= "/">
            <Home></Home>
          </Route>

          <Route exact path= "/Cart">
            <Cart></Cart>
          </Route>

          <Route exact path= "/Detalle/:parametro">
            <ItemDetailContainer></ItemDetailContainer>
          </Route>

          <Route exact path= "/Ofertas">
            <Ofertas></Ofertas>
          </Route>
          </>
        </Switch>
      </BrowserRouter>
    </AppProvider>
  );
}

export default App;


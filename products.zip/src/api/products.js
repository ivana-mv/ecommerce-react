/*export const getProducts = () => {
return new Promise((resolve, reject) => {
    resolve(
        [
            {id: 1, productName: 'Silla', price: 15},
            {id: 2, productName: 'Mesa', price: 20},
            {id: 3, productName: 'Alfombra', price: 25},
            {id: 4, productName: 'Cama', price: 40},
            {id: 5, productName: 'Lámpara', price: 10}

        ]
      )
     })
}

export const getProductsbyId = (parametro) => {
    return new Promise((resolve, reject) => {
        resolve(
             [
                {id: 1, productName: 'Silla', price: 15},
                {id: 2, productName: 'Mesa', price: 20},
                {id: 3, productName: 'Alfombra', price: 25},
                {id: 4, productName: 'Cama', price: 40},
                {id: 5, productName: 'Lámpara', price: 10}
    
            ].filter(function(item){
                if (item.id == parametro){
                return item
                }
             })
          )
         })
    }
    */
import React from 'react';
import { Link } from 'react-router-dom';
import { getProducts } from '../../api/products';
import HomeContainer from '../../components/HomeContainer/HomeContainer';

const Home = () => {



    return (
        <div>
            <h1>Componente Home</h1>
            <a>
                <Link to={'Ofertas'}>
                   <p> Ir a ofertas!! </p>
                </Link>
            </a>
            <HomeContainer></HomeContainer>
        </div>
    )
}

export default Home;